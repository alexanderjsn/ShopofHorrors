
public class Food {

    private String name;
    private int stock;
    private double Price;

    // konstruktor

    public Food(String name, int stock, double Price){
        this.setName(name);
        this.setStock(stock);
        this.setPrice(Price);
    }
    // getters och setters
    public String getName(){

        return name;
    }

    public double getPrice(){

        return Price;
    }

    public int getStock(){

        return stock;
    }

    public void setPrice(double Price){
            this.Price = Price;
        }

    public void setName(String name){
        this.name = name;
    }


    public void setStock(int stock){
        this.stock = stock;
    }

    // uppdaterar lager saldo
    public void updateStock(){

        stock --;
    }
}

